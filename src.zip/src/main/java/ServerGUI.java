
/**
 * ( contains a file for handling clients named: ClientControl )
 * 10. interactive GUI for server to interact with the user.
 * 9. uses plain text communication protocol. 
 */
import java.awt.*;
import java.io.*;
import java.net.*;
import java.util.*;
import javax.swing.*;
import javax.swing.JFrame;
public class ServerGUI {
    final JFrame server_frame;
    final JTextArea area_text;
    final JButton start_button;
    final JButton shut_button;
    final JTextField msg_field;
    final JButton send_button;
    final JLabel status;
    final JPanel top_header;
    private ServerSocket socket_server;
    private ArrayList<ClientControl> clients=new ArrayList<>();
    
    /* GUI interface using JFrames*/
    public ServerGUI(){
    server_frame=new JFrame("Server");
    server_frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
    server_frame.setSize(600, 400);
    
    area_text=new JTextArea();
    area_text.setEditable(false);
    
    start_button=new JButton("Start Server");
    start_button.setBackground(new Color(153,0,0));
    start_button.setForeground(Color.WHITE);
    start_button.addActionListener(e -> startserver());
    
    shut_button= new JButton(" ShutDown");
    shut_button.setBackground(new Color(153,0,0));
    shut_button.setForeground(Color.WHITE);
    shut_button.addActionListener(e -> shutdownserver());
    
    msg_field=new JTextField();
    msg_field.addActionListener(e -> sendmsgfromserver());
    
    send_button=new JButton("Send");
    send_button.addActionListener(e ->sendmsgfromserver());
    send_button.setEnabled(false);
    
    status=new JLabel("Server is not running...",SwingConstants.CENTER);
    status.setOpaque(true);
    status.setBackground(new Color(153,0,0));
    status.setForeground(Color.WHITE);
    status.setFont(new Font("SansSerif", Font.BOLD, 14));
    status.setPreferredSize(new Dimension(600,40));
    
    top_header=new JPanel(new BorderLayout());
    top_header.setPreferredSize(new Dimension(600,50));
    top_header.add(status,BorderLayout.CENTER);
    top_header.add(start_button, BorderLayout.EAST);
    top_header.add(shut_button, BorderLayout.WEST);
    
    JPanel bottom=new JPanel(new BorderLayout());
    bottom.add(msg_field, BorderLayout.CENTER);
    bottom.add(send_button,BorderLayout.EAST);
    
    server_frame.setLayout(new BorderLayout());
    server_frame.add(top_header, BorderLayout.NORTH);
    server_frame.add(new JScrollPane(area_text), BorderLayout.CENTER);
    server_frame.add(bottom, BorderLayout.SOUTH);
    server_frame.setVisible(true);
            
}
    /* Here server is started */
    private void startserver(){
        start_button.setEnabled(false);
        send_button.setEnabled(true);
        start_button.setBackground(new Color(0,102,51));
        status.setText("Server Running on the Port ...");
        status.setBackground(new Color(0,102,51));
        setMsg("The Server is Starting...");
        
        /* 2. accept multiple connection of client through threads */
        new Thread(()->{
            try{
                /* 1. Bind to specific port */
                socket_server=new ServerSocket(3554);
                setMsg("Server started on the port...");
                while(!socket_server.isClosed()){
                    Socket socket=socket_server.accept();
                    setMsg("New Client connected"+ socket.getInetAddress());
                    /* 2. Another file for assigning client the port and handling them */
                    ClientControl clientcontrolling= new ClientControl(socket, clients, this);
                    clients.add(clientcontrolling);
                    new Thread(clientcontrolling).start();
                }
            }catch(IOException e){
                /* 7. log event (if server unavailable */
                setMsg("Server not Responding: "+ e.getMessage());
            }
        }).start();
    }
    /* 4. Send back appropriate response to the client */
    private void sendmsgfromserver(){
        /* 9. plain text*/
        String msg_of_server=msg_field.getText();
        if(!msg_of_server.isEmpty()){
            /* 6. Manage client session ( list the clients) */
            if(msg_of_server.startsWith("//")){
                for(ClientControl cc: clients){
                    setMsg(cc.name);
                    msg_field.setText("");
                }
                return ;
            }
            setMsg("Server: "+ msg_of_server);
            if(msg_of_server.startsWith("@")){
                String[] msg_parts=msg_of_server.split(":",2);
                if(msg_parts.length==2){
                    String target_user=msg_parts[0].substring(1).trim();
                    String msgToSend="Server: "+msg_parts[1].trim();
                    /* 4.1 send messages only to the intended user (unicast( */ 
                    sendMsgToSpecificClient(target_user, msgToSend);
                }else{
                    /* 7. log event if server use invalid format */
                    setMsg("Invalid Format.. use @__: to send message to the intended user");
                }
            }else{
                spreadMessage("Server: "+ msg_of_server);
            }
            msg_field.setText("");
        }
    }
    /* 4.1 (implementation)Only to the intented user */
    public void sendMsgToSpecificClient(String user, String msg ){
        for(ClientControl client: clients){
            if(client.name.equalsIgnoreCase(user)){
                try{
                    client.writeoutput.write(msg);
                    client.writeoutput.newLine();
                    client.writeoutput.flush();
            }catch(IOException e){
                /* 7. log event id user is not identified or avaiilable */
                setMsg(" Error sending to "+ user);
                client.terminateAll();
            }
                return;
        }
        }
        /* 7. handle when wrong username is typed */
    setMsg("Client "+ user +"not found...");
    }
    /* 4.2 broadcast the message when necessary 
    *      give response to the request
    */
    public void spreadMessage(String msg){
        for(ClientControl clientmanager: clients){
            try{
                clientmanager.writeoutput.write(msg);
                clientmanager.writeoutput.newLine();
                clientmanager.writeoutput.flush();
            }catch(IOException e){
                clientmanager.terminateAll();
            }
        }
    }
    /* 3. Recieve the message (fullfill request) and display on server side*/
    public void setMsg(String msg){
        SwingUtilities.invokeLater(()->area_text.append(msg+ "\n"));
    }
    /* 8. handles the shutting down of server gracefully by closing socket and buffer */
    public void shutdownserver(){
        try{
            setMsg("shutting down server");
            for(ClientControl clientmanager: clients){
                clientmanager.writeoutput.write("server is shutting down");
                clientmanager.writeoutput.newLine();
                clientmanager.writeoutput.flush();
                clientmanager.terminateAll();
            }
            clients.clear();
            socket_server.close();
            status.setText("SERVER STOPPED");
        }catch(IOException e){
            setMsg("Error in shutting down..");
        }
    }
    public static void main(String[] args){
        SwingUtilities.invokeLater(ServerGUI::new);
    } 
}
    
