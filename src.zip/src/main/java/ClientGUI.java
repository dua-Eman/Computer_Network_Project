/**
 * Client Interface and GUI
 */
import javax.swing.*;
import java.awt.*;
import java.io.*;
import java.net.*;

/* 7. An interactive interface and GUI for the client, 
*     the Jframe provide the interface.
*/
public class ClientGUI {
    final JFrame client_frame;
    final JTextArea chat_area;
    final JTextField msg_field;
    final JLabel status;
    final JButton send_button;
    private Socket socket;
    private BufferedReader readinput;
    private BufferedWriter writeoutput;
    private String client_name;
    
    /* Using JFrames */
    public ClientGUI(){
        client_frame=new JFrame("Client");
        /* 6. Source to close the connection */
        client_frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        client_frame.setSize(600,400);
        
        client_name=JOptionPane.showInputDialog(client_frame, "Enter your name");
        if(client_name==null||client_name.trim().isEmpty()){
            client_name= "unnamed";
        }
        chat_area=new JTextArea();
        chat_area.setEditable(false);
        
        msg_field=new JTextField();
        msg_field.addActionListener(e -> sendingmsg());
        
        send_button=new JButton("Send");
        send_button.addActionListener(e -> sendingmsg());
        
        status=new JLabel("Connecting to the Server...");
        status.setHorizontalAlignment(SwingConstants.CENTER);
        status.setOpaque(true);
        status.setBackground(new Color(51,102,204));
        status.setForeground(Color.WHITE);
        status.setFont(new Font("SansSerif", Font.BOLD,14));
        status.setPreferredSize(new Dimension(600,40));
        
        JPanel bottom=new JPanel(new BorderLayout());
        JPanel panel_button=new JPanel(new FlowLayout(FlowLayout.RIGHT));
        panel_button.add(send_button);
        
        bottom.add(msg_field, BorderLayout.CENTER);
        bottom.add(panel_button, BorderLayout.EAST);
        
        client_frame.setLayout(new BorderLayout());
        client_frame.add(status, BorderLayout.NORTH);
        client_frame.add(new JScrollPane(chat_area),BorderLayout.CENTER);
        client_frame.add(bottom,BorderLayout.SOUTH);
        client_frame.setVisible(true);
        
        connectWithServer();    
    }
    /* 1. Connection with the server */
    private void connectWithServer(){
        try{
            /* 1.1 Client initiate with the port */
            socket=new Socket("localhost", 3554);     
            writeoutput=new BufferedWriter(new OutputStreamWriter(socket.getOutputStream()));
            readinput=new BufferedReader(new InputStreamReader(socket.getInputStream()));
            
            writeoutput.write(client_name);
            writeoutput.newLine();
            writeoutput.flush();
            
            status. setText("connected as "+ client_name+ " successfully");
            new Thread(this::listenToMsg).start();
        }catch(IOException e){
            /* 4. Handle connection error when port is not matched*/
            JOptionPane.showMessageDialog(client_frame, "Failed to Connect: "
                    + e.getMessage(), " connection error", JOptionPane.ERROR_MESSAGE);
            System.exit(1);
        }
    }
    /* 2. client send messages, commands, and request to server */
    private void sendingmsg(){ 
        try{
            String msg=msg_field.getText();  
            if(!msg.isEmpty()){
                writeoutput.write(msg);
                writeoutput.newLine();
                writeoutput.flush();
                msg_field.setText("");
            }
        }catch(IOException e){
            /* Handles when server is not available */
            JOptionPane.showMessageDialog(client_frame, "Error in sending message ",
                    " error", JOptionPane.ERROR_MESSAGE);
            terminateAll();
        }
    }
    /* 3. client can receive data, and messages from the server */
    private void listenToMsg(){       
        try{
            String server_msg;              
            while(socket.isConnected()){
                server_msg=readinput.readLine();
                if(server_msg==null)break;
                
                String new_msg=server_msg;
                SwingUtilities.invokeLater(()-> chat_area.append(new_msg+"\n"));
            }
        }catch(IOException e){
            SwingUtilities.invokeLater(()->{
                status.setText("Disconnected from the Server");
                /* 4. handles the connection error when server got terminated */
                chat_area.append("Connection Lost.."); 
                /* 5. if server drops manually send msg to restart it by 
                      closing the client window and restarting the server again.
                */
                chat_area.append("Restart connection by closing the window and starting the server again");
            });
            terminateAll();
        }
    }
    /*6. This method hold the termination in case of message sending or connection  error  */
    private void terminateAll(){            
        try{
            if(readinput!=null)readinput.close();
            if(writeoutput!=null)writeoutput.close();
            if(socket!=null)socket.close();
        }
        catch(IOException e){
            e.printStackTrace();
        }
    }
    public static void main(String[] args){
        SwingUtilities.invokeLater(ClientGUI::new);
    }
    
}
