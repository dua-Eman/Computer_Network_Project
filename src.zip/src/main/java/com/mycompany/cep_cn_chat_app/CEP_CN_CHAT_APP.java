/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 */

package com.mycompany.cep_cn_chat_app;

/**
 *
 * @author LeNoVo
 */
public class CEP_CN_CHAT_APP {

    public static void main(String[] args) {
        System.out.println("Hello World!");
    }
}
