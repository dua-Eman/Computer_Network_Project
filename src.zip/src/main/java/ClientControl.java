/**
 * This is the handling of the client that interact with the server.
 */
import java.io.*;
import java.net.*;
import java.util.*;

public class ClientControl implements Runnable {
    private Socket socket;
    private BufferedReader readinput;
    BufferedWriter writeoutput;
    String name;
    private ArrayList<ClientControl> clientlist;
    private ServerGUI serverside;
    
    /* initialization of client using socket */
    public ClientControl(Socket socket, ArrayList<ClientControl> clients, ServerGUI serverGUI){
        try{
            this.socket=socket;
            this.clientlist=clients;
            this.serverside=serverGUI;
            this.readinput=new BufferedReader(new InputStreamReader(socket.getInputStream()));
            this.writeoutput=new BufferedWriter(new OutputStreamWriter(socket.getOutputStream()));
            this.name=readinput.readLine();
            serverside.setMsg(name + " has joined the chat");
    }catch(IOException e){
        terminateAll();
    }
    }
    /* 3. process the client request */
    @Override
    public void run(){
        /*9. plain text */
        String client_msg;
        while(socket.isConnected()){
            try{
                client_msg=readinput.readLine();
                if(client_msg==null)break;
                
                /* handle malinformed or bad request safely */
                if(Invalidmsg(client_msg)){
                    writeoutput.write("Server: I can't understand. please resend the message.");
                    writeoutput.newLine();
                    writeoutput.flush();
                    continue;
                }
                String newmsg=name+ ": "+ client_msg;
                serverside.setMsg(newmsg);
                
                writeoutput.write("You: "+ client_msg);
                writeoutput.newLine();
                writeoutput.flush();
            }catch(IOException e){
                terminateAll();
                break;
            }
        } 
    }
    /* 5. handling of bad requests */
    public boolean Invalidmsg(String msg){
        if(msg==null||msg.trim().isEmpty())return true;
        return !msg.matches(".*[a-zA-Z0-9].*");
    }
    /* 8. closes connection */
    public void terminateAll(){
        try{
            if(readinput!=null)readinput.close();
            if(writeoutput!=null)writeoutput.close();
            if(socket!=null)socket.close();
            clientlist.remove(this);
            serverside.setMsg(name+ " has left the chat.");
        }catch(IOException e){
            e.printStackTrace();
        }
    }  
}
